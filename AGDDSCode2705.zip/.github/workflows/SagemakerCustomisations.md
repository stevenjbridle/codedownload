# Sagemaker Studio Customisations

All customisations are applied to the defual user profile after the domain has been created. Note that this is not specified in the CDK as there is currently not a one to one mapping between the CDK and the CLI. The Following are examples of the customisations accessable via the `update-domain --default-user-settings` cli command accessable [here](https://docs.aws.amazon.com/cli/latest/reference/sagemaker/update-domain.html).

> [!NOTE]
> You must also use `--domain-id` as a paramater to update the default user settings:
>
> `aws sagemaker update-domain --domain-id DOMAIN_ID --default-user-settings '{DEFAULT_USER_SETTINGS}'`

## Code Editor App Settings
Can be done via [CDK](https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_sagemaker.CfnUserProfile.CodeEditorAppSettingsProperty.html#example)
```json
"CodeEditorAppSettings":
{
    "DefaultResourceSpec": DEFAULT_RESOURCE_SPECIFICATION,
    "AppLifecycleManagement": APP_LIFECYCLE_MANAGEMENT,
}
```

Links

-   [DEFAULT_RESOURCE_SPECIFICATION](#default-resource-specification)
-   [APP_LIFECYCLE_MANAGEMENT](#app-lifecycle-management)

## Jupyter Lab App Settings

```json
"JupyterLabAppSettings":
{
    "DefaultResourceSpec": DEFAULT_RESOURCE_SPECIFICATION,
    "AppLifecycleManagement": APP_LIFECYCLE_MANAGEMENT
}
```

> [!NOTE] Need to check if code repo setup/connectivity to see if this is actually going to work in an isolated environment

Links

-   [DEFAULT_RESOURCE_SPECIFICATION](#default-resource-specification)
-   [APP_LIFECYCLE_MANAGEMENT](#app-lifecycle-management)

## Default Resource Specification

```json
{
      "SageMakerImageArn": "string",
      "SageMakerImageVersionArn": "string",
      "SageMakerImageVersionAlias": "string",
      "InstanceType": INSTANCE_TYPE
}
```

Links

-   [INSTANCE_TYPE](#instance-type)

## App Lifecycle Management
To be applied in the CDK config on creation of the domain instead of in the config for updating the configuration via an API call.
```json
"IdleSettings":
{
    "LifecycleManagement": "ENABLED"|"DISABLED",
    "IdleTimeoutInMinutes": integer,
    "MinIdleTimeoutInMinutes": integer,
    "MaxIdleTimeoutInMinutes": integer
}
```

## Instance Type

For more information on the instance types, look [here](https://docs.aws.amazon.com/sagemaker/latest/APIReference/API_StudioWebPortalSettings.html)


```json
"InstanceType":
    "system"|
    "ml.t3.micro"|
    "ml.t3.small"|
    "ml.t3.medium"|
    "ml.t3.large"|
    "ml.t3.xlarge"|
    "ml.t3.2xlarge"|
    "ml.m5.large"|
    "ml.m5.xlarge"|
    "ml.m5.2xlarge"|
    "ml.m5.4xlarge"|
    "ml.m5.8xlarge"|
    "ml.m5.12xlarge"|
    "ml.m5.16xlarge"|
    "ml.m5.24xlarge"|
    "ml.m5d.large"|
    "ml.m5d.xlarge"|
    "ml.m5d.2xlarge"|
    "ml.m5d.4xlarge"|
    "ml.m5d.8xlarge"|
    "ml.m5d.12xlarge"|
    "ml.m5d.16xlarge"|
    "ml.m5d.24xlarge"|
    "ml.c5.large"|
    "ml.c5.xlarge"|
    "ml.c5.2xlarge"|
    "ml.c5.4xlarge"|
    "ml.c5.9xlarge"|
    "ml.c5.12xlarge"|
    "ml.c5.18xlarge"|
    "ml.c5.24xlarge"|
    "ml.p3.2xlarge"|
    "ml.p3.8xlarge"|
    "ml.p3.16xlarge"|
    "ml.p3dn.24xlarge"|
    "ml.g4dn.xlarge"|
    "ml.g4dn.2xlarge"|
    "ml.g4dn.4xlarge"|
    "ml.g4dn.8xlarge"|
    "ml.g4dn.12xlarge"|
    "ml.g4dn.16xlarge"|
    "ml.r5.large"|
    "ml.r5.xlarge"|
    "ml.r5.2xlarge"|
    "ml.r5.4xlarge"|
    "ml.r5.8xlarge"|
    "ml.r5.12xlarge"|
    "ml.r5.16xlarge"|
    "ml.r5.24xlarge"|
    "ml.g5.xlarge"|
    "ml.g5.2xlarge"|
    "ml.g5.4xlarge"|
    "ml.g5.8xlarge"|
    "ml.g5.16xlarge"|
    "ml.g5.12xlarge"|
    "ml.g5.24xlarge"|
    "ml.g5.48xlarge"|
    "ml.g6.xlarge"|
    "ml.g6.2xlarge"|
    "ml.g6.4xlarge"|
    "ml.g6.8xlarge"|
    "ml.g6.12xlarge"|
    "ml.g6.16xlarge"|
    "ml.g6.24xlarge"|
    "ml.g6.48xlarge"|
    "ml.g6e.xlarge"|
    "ml.g6e.2xlarge"|
    "ml.g6e.4xlarge"|
    "ml.g6e.8xlarge"|
    "ml.g6e.12xlarge"|
    "ml.g6e.16xlarge"|
    "ml.g6e.24xlarge"|
    "ml.g6e.48xlarge"|
    "ml.geospatial.interactive"|
    "ml.p4d.24xlarge"|
    "ml.p4de.24xlarge"|
    "ml.trn1.2xlarge"|
    "ml.trn1.32xlarge"|
    "ml.trn1n.32xlarge"|
    "ml.p5.48xlarge"|
    "ml.m6i.large"|
    "ml.m6i.xlarge"|
    "ml.m6i.2xlarge"|
    "ml.m6i.4xlarge"|
    "ml.m6i.8xlarge"|
    "ml.m6i.12xlarge"|
    "ml.m6i.16xlarge"|
    "ml.m6i.24xlarge"|
    "ml.m6i.32xlarge"|
    "ml.m7i.large"|
    "ml.m7i.xlarge"|
    "ml.m7i.2xlarge"|
    "ml.m7i.4xlarge"|
    "ml.m7i.8xlarge"|
    "ml.m7i.12xlarge"|
    "ml.m7i.16xlarge"|
    "ml.m7i.24xlarge"|
    "ml.m7i.48xlarge"|
    "ml.c6i.large"|
    "ml.c6i.xlarge"|
    "ml.c6i.2xlarge"|
    "ml.c6i.4xlarge"|
    "ml.c6i.8xlarge"|
    "ml.c6i.12xlarge"|
    "ml.c6i.16xlarge"|
    "ml.c6i.24xlarge"|
    "ml.c6i.32xlarge"|
    "ml.c7i.large"|
    "ml.c7i.xlarge"|
    "ml.c7i.2xlarge"|
    "ml.c7i.4xlarge"|
    "ml.c7i.8xlarge"|
    "ml.c7i.12xlarge"|
    "ml.c7i.16xlarge"|
    "ml.c7i.24xlarge"|
    "ml.c7i.48xlarge"|
    "ml.r6i.large"|
    "ml.r6i.xlarge"|
    "ml.r6i.2xlarge"|
    "ml.r6i.4xlarge"|
    "ml.r6i.8xlarge"|
    "ml.r6i.12xlarge"|
    "ml.r6i.16xlarge"|
    "ml.r6i.24xlarge"|
    "ml.r6i.32xlarge"|
    "ml.r7i.large"|
    "ml.r7i.xlarge"|
    "ml.r7i.2xlarge"|
    "ml.r7i.4xlarge"|
    "ml.r7i.8xlarge"|
    "ml.r7i.12xlarge"|
    "ml.r7i.16xlarge"|
    "ml.r7i.24xlarge"|
    "ml.r7i.48xlarge"|
    "ml.m6id.large"|
    "ml.m6id.xlarge"|
    "ml.m6id.2xlarge"|
    "ml.m6id.4xlarge"|
    "ml.m6id.8xlarge"|
    "ml.m6id.12xlarge"|
    "ml.m6id.16xlarge"|
    "ml.m6id.24xlarge"|
    "ml.m6id.32xlarge"|
    "ml.c6id.large"|
    "ml.c6id.xlarge"|
    "ml.c6id.2xlarge"|
    "ml.c6id.4xlarge"|
    "ml.c6id.8xlarge"|
    "ml.c6id.12xlarge"|
    "ml.c6id.16xlarge"|
    "ml.c6id.24xlarge"|
    "ml.c6id.32xlarge"|
    "ml.r6id.large"|
    "ml.r6id.xlarge"|
    "ml.r6id.2xlarge"|
    "ml.r6id.4xlarge"|
    "ml.r6id.8xlarge"|
    "ml.r6id.12xlarge"|
    "ml.r6id.16xlarge"|
    "ml.r6id.24xlarge"|
    "ml.r6id.32xlarge"
```

## Sagemaker Studio Web Portal Settings

`"StudioWebPortalSettings": {}`

```typescript
{
  hiddenAppTypes: [APP_TYPE],
  hiddenMlTools: [ML_TOOL],
}
```

### ML Tool

```json
hiddenMlTools: 
[
    "AutoMl",
    "Comet",
    "DataWrangler",
    "DeepchecksLLMEvaluation",
    "EmrClusters",
    "Endpoints",
    "Experiments",
    "FeatureStore",
    "Fiddler",
    "HyperPodClusters"
    "InferenceOptimization",
    "InferenceRecommender",
    "JumpStart",
    "LakeraGuard",
    "ModelEvaluation",
    "Models",
    "PerformanceEvaluation",
    "Pipelines",
    "Projects",
    "Training"
]

```

#### IAM policy for explicit denial


Looks like there is no way to do explicit denial via security tags so will need to be done in the sagemaker full access hardening step. This is a larger piece of work which will likely need its own document.

---

### Restrict App Types

#### Hide

```json
"HiddenAppTypes":
[
    "Canvas"
    "CodeEditor",
    "DetailedProfiler",
    "JupyterLab",
    "JupyterServer",
    "KernelGateway",
    "RSessionGateway",
    "RStudioServerPro",
    "TensorBoard"
]
```

#### IAM policy for explicit denial

Denial via [Create App](https://docs.aws.amazon.com/sagemaker/latest/APIReference/API_CreateApp.html#sagemaker-CreateApp-request-AppType) request.

```typescript
new iam.PolicyStatement({
    actions: ['sagemaker:CreateApp'],
    effect: iam.Effect.DENY,
    resources: ['*'],
    conditions: {
        'ForAllValues:StringNotLike': {
            'sagemaker:ImageArns': [`arn:aws:sagemaker:*:*:AppType/APP_NAME`],
        },
    },
})
```

---

### Restrict Instance Types

#### Hide

```json
"HiddenInstanceTypes":
[
    INSTANCE_TYPE
]
```

Links

-   [INSTANCE_TYPE](#instance-type)

#### IAM policy for explicit denial

Denial via [Create App](https://docs.aws.amazon.com/sagemaker/latest/APIReference/API_CreateApp.html#sagemaker-CreateApp-request-AppType) request.

```typescript
new iam.PolicyStatement({
    actions: ['sagemaker:CreateApp'],
    effect: iam.Effect.DENY,
    resources: ['*'],
    conditions: {
        'ForAllValues:StringNotLike': {
            'sagemaker:InstanceTypes': [INSTANCE_TYPE],
        },
    },
})
```

Links

-   [INSTANCE_TYPE](#instance-type)

---

### Restrict Sagemaker Images

#### Hide

Currently no way to hide all default sagemaker images, so need to keep updating the 'VersionAliases' array to hide all new images

**TODO**: Find a way to hide all verison aliases without needing to specify them individully.
```json
"HiddenSageMakerImageVersionAliases":
[
    {
        "SageMakerImageName": "sagemaker_distribution",
        "VersionAliases": ["string"]
    }
]
```

#### IAM policy for explicit denial

Denial via [Create App](https://docs.aws.amazon.com/sagemaker/latest/APIReference/API_CreateApp.html#sagemaker-CreateApp-request-AppType) request.

```typescript
new iam.PolicyStatement({
    actions: ['sagemaker:CreateApp'],
    effect: iam.Effect.DENY,
    resources: ['*'],
    conditions: {
        'ForAllValues:StringNotLike': {
            'sagemaker:ImageArns': [`arn:aws:sagemaker:*:*:image/IMAGE_NAME`],
        },
    },
})
```

## Recommended Configuration

### Recommended Instance Types


> [!NOTE]
> The [documentation](https://docs.aws.amazon.com/sagemaker/latest/dg/code-editor-use-instances.html) specifies the following guidence for instance types: 'For most use cases, you should use a `ml.t3.medium`. This is the default instance type for CPU-based SageMaker images, and is available as part of the [AWS Free Tier](https://aws.amazon.com/free)

| Instance | Use Case | GPUs | vCPU | Memory (GiB) | GPU Memory (GiB) | Instance Storage (GB) | Price per Hour (Usd)
|----------|:--------:|:------:|:------:|:------:|:------:|:------:| :------:|
| ml.t3.medium | General purpose | N/A | 2 | 4 | N/A | Amazon EBS Only | $0.063
| ml.t3.large | General purpose | N/A | 2 | 8 | N/A | Amazon EBS Only | $0.127
| ml.t3.xlarge | General purpose | N/A | 4 | 16 | N/A | Amazon EBS Only | $0.253
| ml.t3.2xlarge | General purpose | N/A | 8 | 32 | N/A | Amazon EBS Only | $0.507
| ml.g5.xlarge | Accelerated computing | 1 | 4 | 16 | 24 | 1 x 250 NVMe SSD | $1.831
| ml.g5.2xlarge | Accelerated computing | 1 | 8 | 32 | 24 | 1 x 450 NVMe SSD | $1.97
| ml.g5.4xlarge | Accelerated computing | 1 | 16 | 64 | 24 | 1 x 600 NVMe SSD | $2.639

Links
- Sagemaker instance pricing [link](https://aws.amazon.com/sagemaker-ai/pricing/)
- Sagemaker instance information [link](https://docs.aws.amazon.com/sagemaker/latest/dg/notebooks-available-instance-types.html)

### IAM Policy For Recommended Configuration

```typescript
new iam.PolicyStatement({
    actions: ['sagemaker:CreateApp'],
    effect: iam.Effect.DENY,
    resources: ['*'],
    conditions: {
        'ForAllValues:StringNotLike': {
            'sagemaker:ImageArns': [`arn:aws:sagemaker:*:*:image/IMAGE_NAME`],
        },
        'ForAllValues:StringNotLike': {
            'sagemaker:InstanceTypes': 
            [
                "ml.t3.medium",
                "ml.t3.large",
                "ml.t3.xlarge",
                "ml.t3.2xlarge",
                "ml.g5.xlarge",
                "ml.g5.2xlarge",
                "ml.g5.4xlarge",
            ],
        },
    },
})
```

### Json For Recommended Confiuration

```json
{
    "StudioWebPortalSettings":
    {
        "HiddenMlTools":
        [
            "AutoMl",
            "Comet",
            "DataWrangler",
            "DeepchecksLLMEvaluation",
            "EmrClusters",
            "Endpoints",
            "Experiments",
            "FeatureStore",
            "Fiddler",
            "HyperPodClusters",
            "InferenceOptimization",
            "InferenceRecommender",
            "JumpStart",
            "LakeraGuard",
            "ModelEvaluation",
            "Models",
            "PerformanceEvaluation",
            "Pipelines",
            "Projects",
            "Training"
        ],
        "HiddenAppTypes":
        [
            "Canvas",
            "DetailedProfiler",
            "JupyterServer",
            "KernelGateway",
            "RSessionGateway",
            "RStudioServerPro",
            "TensorBoard"
        ],
        "HiddenSageMakerImageVersionAliases": 
        [
            {
                "SageMakerImageName": "sagemaker_distribution",
                "VersionAliases": 
                [
                    "3.0",
                    "2.6",
                    "2.4",
                    "2.3",
                    "2.2",
                    "2.1",
                    "2.0",
                    "1.13",
                    "1.12",
                    "1.11",
                    "1.10",
                    "1.9",
                    "1.8",
                    "1.7",
                    "1.6"
                ]
            }
        ],
        "HiddenInstanceTypes":
        [
            "ml.t3.micro",
            "ml.t3.small",
            "ml.m5.large",
            "ml.m5.xlarge",
            "ml.m5.2xlarge",
            "ml.m5.4xlarge",
            "ml.m5.8xlarge",
            "ml.m5.12xlarge",
            "ml.m5.16xlarge",
            "ml.m5.24xlarge",
            "ml.m5d.large",
            "ml.m5d.xlarge",
            "ml.m5d.2xlarge",
            "ml.m5d.4xlarge",
            "ml.m5d.8xlarge",
            "ml.m5d.12xlarge",
            "ml.m5d.16xlarge",
            "ml.m5d.24xlarge",
            "ml.c5.large",
            "ml.c5.xlarge",
            "ml.c5.2xlarge",
            "ml.c5.4xlarge",
            "ml.c5.9xlarge",
            "ml.c5.12xlarge",
            "ml.c5.18xlarge",
            "ml.c5.24xlarge",
            "ml.p3.2xlarge",
            "ml.p3.8xlarge",
            "ml.p3.16xlarge",
            "ml.p3dn.24xlarge",
            "ml.g4dn.xlarge",
            "ml.g4dn.2xlarge",
            "ml.g4dn.4xlarge",
            "ml.g4dn.8xlarge",
            "ml.g4dn.12xlarge",
            "ml.g4dn.16xlarge",
            "ml.r5.large",
            "ml.r5.xlarge",
            "ml.r5.2xlarge",
            "ml.r5.4xlarge",
            "ml.r5.8xlarge",
            "ml.r5.12xlarge",
            "ml.r5.16xlarge",
            "ml.r5.24xlarge",
            "ml.g5.8xlarge",
            "ml.g5.16xlarge",
            "ml.g5.12xlarge",
            "ml.g5.24xlarge",
            "ml.g5.48xlarge",
            "ml.g6.xlarge",
            "ml.g6.2xlarge",
            "ml.g6.4xlarge",
            "ml.g6.8xlarge",
            "ml.g6.12xlarge",
            "ml.g6.16xlarge",
            "ml.g6.24xlarge",
            "ml.g6.48xlarge",
            "ml.g6e.xlarge",
            "ml.g6e.2xlarge",
            "ml.g6e.4xlarge",
            "ml.g6e.8xlarge",
            "ml.g6e.12xlarge",
            "ml.g6e.16xlarge",
            "ml.g6e.24xlarge",
            "ml.g6e.48xlarge",
            "ml.p4d.24xlarge",
            "ml.p4de.24xlarge",
            "ml.trn1.2xlarge",
            "ml.trn1.32xlarge",
            "ml.trn1n.32xlarge",
            "ml.p5.48xlarge",
            "ml.m6i.large",
            "ml.m6i.xlarge",
            "ml.m6i.2xlarge",
            "ml.m6i.4xlarge",
            "ml.m6i.8xlarge",
            "ml.m6i.12xlarge",
            "ml.m6i.16xlarge",
            "ml.m6i.24xlarge",
            "ml.m6i.32xlarge",
            "ml.m7i.large",
            "ml.m7i.xlarge",
            "ml.m7i.2xlarge",
            "ml.m7i.4xlarge",
            "ml.m7i.8xlarge",
            "ml.m7i.12xlarge",
            "ml.m7i.16xlarge",
            "ml.m7i.24xlarge",
            "ml.m7i.48xlarge",
            "ml.c6i.large",
            "ml.c6i.xlarge",
            "ml.c6i.2xlarge",
            "ml.c6i.4xlarge",
            "ml.c6i.8xlarge",
            "ml.c6i.12xlarge",
            "ml.c6i.16xlarge",
            "ml.c6i.24xlarge",
            "ml.c6i.32xlarge",
            "ml.c7i.large",
            "ml.c7i.xlarge",
            "ml.c7i.2xlarge",
            "ml.c7i.4xlarge",
            "ml.c7i.8xlarge",
            "ml.c7i.12xlarge",
            "ml.c7i.16xlarge",
            "ml.c7i.24xlarge",
            "ml.c7i.48xlarge",
            "ml.r6i.large",
            "ml.r6i.xlarge",
            "ml.r6i.2xlarge",
            "ml.r6i.4xlarge",
            "ml.r6i.8xlarge",
            "ml.r6i.12xlarge",
            "ml.r6i.16xlarge",
            "ml.r6i.24xlarge",
            "ml.r6i.32xlarge",
            "ml.r7i.large",
            "ml.r7i.xlarge",
            "ml.r7i.2xlarge",
            "ml.r7i.4xlarge",
            "ml.r7i.8xlarge",
            "ml.r7i.12xlarge",
            "ml.r7i.16xlarge",
            "ml.r7i.24xlarge",
            "ml.r7i.48xlarge",
            "ml.m6id.large",
            "ml.m6id.xlarge",
            "ml.m6id.2xlarge",
            "ml.m6id.4xlarge",
            "ml.m6id.8xlarge",
            "ml.m6id.12xlarge",
            "ml.m6id.16xlarge",
            "ml.m6id.24xlarge",
            "ml.m6id.32xlarge",
            "ml.c6id.large",
            "ml.c6id.xlarge",
            "ml.c6id.2xlarge",
            "ml.c6id.4xlarge",
            "ml.c6id.8xlarge",
            "ml.c6id.12xlarge",
            "ml.c6id.16xlarge",
            "ml.c6id.24xlarge",
            "ml.c6id.32xlarge",
            "ml.r6id.large",
            "ml.r6id.xlarge",
            "ml.r6id.2xlarge",
            "ml.r6id.4xlarge",
            "ml.r6id.8xlarge",
            "ml.r6id.12xlarge",
            "ml.r6id.16xlarge",
            "ml.r6id.24xlarge",
            "ml.r6id.32xlarge"
        ]
    },
    "CodeEditorAppSettings":
    {
        "DefaultResourceSpec": 
        {
            "InstanceType": "ml.t3.medium"
        },
        "AppLifecycleManagement":
        {
            "IdleSettings":
            {
                "LifecycleManagement": "ENABLED",
                "IdleTimeoutInMinutes": 60,
                "MinIdleTimeoutInMinutes": 60,
                "MaxIdleTimeoutInMinutes": 180
            }
        }
    },
    "JupyterLabAppSettings": 
    {
        "DefaultResourceSpec": 
        {
            "InstanceType": "ml.t3.medium"
        },
        "AppLifecycleManagement":
        {
            "IdleSettings":
            {
                "LifecycleManagement": "ENABLED",
                "IdleTimeoutInMinutes": 60,
                "MinIdleTimeoutInMinutes": 60,
                "MaxIdleTimeoutInMinutes": 180
            }
        }
    }

}
```