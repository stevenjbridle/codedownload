# Backups

When a sagemaker domain is created, an EFS (elastic file system) file system is automatically created with it. The sagemaker domain manages multiple aspects of the efs (eg security groups). To back up the automatically created efs file system via cdk, you need to import the efs file system which requires a security group as an imput (see [documentation](https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_efs-readme.html)). To look up a security group requires inputs to be concrete and not tokens which means they would need to be stored in SSM parameters and then retrieved. This could not happen in the samge cdk deploy statement so an additional step would have needed to be created. Hence, the following method uses cli commands with a basic breakdown of:

1. Get the EFS ID's from the output.json file produced by the cdk deploy command
1. Convert the EFS ID's into ARN's (efs ARN's are deterministic)
1. Create a backup selection json object and pass in relevant variables
1. Delete any backup selection on the backup plan (as there should only be the most current backup selection on the plan, and there is no cli command to update a backup selection)
1. Create new backup selection on the backup plan

The EFS file system that is created with the sagemaker domain manages multiple things

```bash
# Array for storing EFS ARN's that are required to be specified in a backup selection
declare -a EFS_ARNs=()

# Get the EFS ID's from the outputs file produced by the CDK deploy command (see the cdk-deploy.yaml file)
EFS_IDs=($(jq -r -c 'to_entries |map(select(.key | startswith("SageMakerCore")) | .value.sageMakerEFSID) | .[]' ./outputs.json))

# Format the EFS ID's into ARN's as they are deterministic
for EFS_ID in "${EFS_IDs[@]}"
do
    printf -v EFS_ARN "arn:aws:elasticfilesystem:%s:%s:file-system/%s" ${{env.CDK_DEFAULT_REGION}} ${{env.CDK_DEFAULT_ACCOUNT}} $EFS_ID
    EFS_ARNs+=($EFS_ARN)
done

# Convert the bash array into a json formatted list
BACKUP_RESOURCES=$(jq -c -n  '$ARGS.positional' --args ${EFS_ARNs[@]})

# Create the backup selection json object as specified in:
#   https://docs.aws.amazon.com/cli/latest/reference/backup/create-backup-selection.html
BACKUP_SELECTION=$( jq -n \
    --arg IamRole "${{env.SAGEMAKER_BACKUP_ROLE_ARN}}" \
    --argjson Resources "$BACKUP_RESOURCES" \
    '{"SelectionName": "EFS_Backup_Selection","IamRoleArn": $IamRole, "Resources": $Resources}'
)

# Get backup selection on the backup plan
# TODO: Will only delete a single backup selection, will not delete all backup selections on the backup plan
OLD_BACKUP_SELECTION_ID=$(aws backup list-backup-selections --backup-plan-id ${{env.SAGEMAKER_BACKUP_PLAN_ID}} | \
    jq -r -c '.BackupSelectionsList.[].SelectionId')

# If a backup selection exists, delete it
if [ -n "$OLD_BACKUP_SELECTION_ID" ]; then
    aws backup delete-backup-selection --backup-plan-id "${{env.SAGEMAKER_BACKUP_PLAN_ID}}" --selection-id "$OLD_BACKUP_SELECTION_ID";
fi

# Add new backup selection
aws backup create-backup-selection --backup-plan-id "${{env.SAGEMAKER_BACKUP_PLAN_ID}}" --backup-selection "$BACKUP_SELECTION"

```
