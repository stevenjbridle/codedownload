# CI/CD

This folder contains a reference framework for deploying and configuring SageMaker. Workflows authenticate to [AWS using OIDC](https://github.com/shinesolutions/day-one-deploy/tree/main/oidc-auth#oidc-with-github-and-aws). Their order and dependencies are described by the diagram below.

It should be read left to right, then top to bottom. I.e., start at the left-most top-most item, then read from left to right in that row. Now, go to the left-most second-top-most item, and read from left to right in that row, etc. Jobs that run in parallel are contained within a `par` block.

```mermaid
sequenceDiagram
    loop
    GitHub Action (./cdk-test.yaml)->>GitHub Action (./cdk-test.yaml): Run Tests
    end
    par
        GitHub Action (./cdk-deploy.yaml-deploy)->>AWS: Deploy CDK Infra

        GitHub Action (./ecr-image-push.yaml)->>ECR: Publish Image
    end
    par
      GitHub Action (./cdk-deploy.yaml-configure)->>AWS: Configure Deployed Infra
      GitHub Action (./sagemaker-image-pull)->>AWS: Create New SageMaker Image Version and Remove Previous
    end
    AWS->>ECR: SageMaker Image Version Now References ECR Image
```

> [!NOTE]
> Where a Workflow is referred to in the format `./workflow-filename.yaml-additional_text`, that Workflow contains multiple Jobs and `additional_text` is the Job being referred to. If `additional_text` is not present, the Workflow contains only one Job.

The following are important points regarding decisions made in this deployment framework, and considerations for expansion to production use-cases:

-   SageMaker does not have full CloudFormation coverage, hence it also does not have full CDK coverage. Because of this, we are required to run an additional configuration step after deployent where CLI calls are made to handle these gaps
    -   https://docs.aws.amazon.com/sagemaker/latest/dg/studio-updated-ui-customize-instances-images.html
    -   https://github.com/aws-cloudformation/cloudformation-coverage-roadmap/issues/2250
-   A SageMaker Image is a "container" for SageMaker Image Versions which reference specific container images in a registry. As such, a SageMaker Image can sensibly be defined in the CDK. While SageMaker Image Versions _can_ be defined in the CDK, given new images can be published dynamically, we create Versions in response to the publishing of a new image via API calls in a Workflow (`./sagemaker-image-pull.yaml`).
-   We delete the previous SageMaker Image Version when a new one is created, so that a user only ever has access to the latest version of the image. If this does not suit your use case, it can be removed
-   For simplicity, this reference framework considers the case of a single deployment environment. This is unlikely for a production use case
    -   There are two lenses through which multiple environments (e.g. `dev`, `staging`, `prod`) can be considered
        -   Infrastructure (e.g., an administrator may want to trial configurations in an environment developers aren't actively working in)
        -   Data (multiple Domains might be deployed into different AWS accounts with different access controls and data access)
    -   As an example, one might have a `dev` environment for infra and then the `prod` infra environment might be composed of many deployments that comprise `dev`, `staging` and `prod` environments with respect to data and development within SageMaker
