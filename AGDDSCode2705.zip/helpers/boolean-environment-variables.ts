// TODO(priority: low): Is there a native TypeScript function to do this?
export function getBooleanEnvVar(envVar: string): boolean {
    if (envVar.toLowerCase() === 'false') {
        return false
    } else if (envVar.toLowerCase() === 'true') {
        return true
    } else {
        throw new Error('Expected either true or false')
    }
}
