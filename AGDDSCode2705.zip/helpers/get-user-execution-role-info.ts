import { SageMakerRoles } from '../lib/sagemaker-roles-stack'
import * as iam from 'aws-cdk-lib/aws-iam'

type accessLevel = 'ReadOnly' | 'FullAccess'

export interface UserExecutionRoleInfo {
    restricted: boolean
    accessLevel: accessLevel
    role: iam.Role | undefined
}

// Roles are conditionally created in sageMakerRolesStack based on the value of props.restricted - get the Roles that
// were created and provide additional metadata, for other Stacks to consume
export function getUserExecutionRoleInfo(
    sageMakerRolesStack: SageMakerRoles,
    restricted: boolean
): UserExecutionRoleInfo[] {
    const sageMakerUserExecutionRoleInfo: UserExecutionRoleInfo[] = []
    if (restricted) {
        sageMakerUserExecutionRoleInfo.push({
            restricted: true,
            accessLevel: 'FullAccess',
            role: sageMakerRolesStack.sageMakerFullAccessRestrictedUserExecutionRole,
        })
        sageMakerUserExecutionRoleInfo.push({
            restricted: true,
            accessLevel: 'ReadOnly',
            role: sageMakerRolesStack.sageMakerReadOnlyRestrictedUserExecutionRole,
        })
    } else {
        sageMakerUserExecutionRoleInfo.push({
            restricted: false,
            accessLevel: 'ReadOnly',
            role: sageMakerRolesStack.sageMakerReadOnlyUnrestrictedUserExecutionRole,
        })

        sageMakerUserExecutionRoleInfo.push({
            restricted: false,
            accessLevel: 'FullAccess',
            role: sageMakerRolesStack.sageMakerFullAccessUnrestrictedUserExecutionRole,
        })
    }
    return sageMakerUserExecutionRoleInfo
}
