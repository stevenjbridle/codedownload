import { SageMakerImageRepoMap } from '../lib/sagemaker-image-stack'

// TODO: Build image map from a file stored in the repo, or from values in Parameter store instead of from a string
//       of comma separated pairs of values. That would be a more robust solution less likely to be misconfigured

// Used to create a SageMakerImageRepoMap from a string of values of form: repoarn1,imagename1,repoarn2,imagename2,...,repoarnN,imagenameN
// E.g.,
/*
export IMAGE_NAME='codeimage'
export REPOSITORY=sagemaker/code-image
export SAGEMAKER_IMAGE_MAP="arn:aws:ecr:${AWS_DEFAULT_REGION}:${AWS_DEFAULT_ACCOUNT}:repository/${REPOSITORY},${IMAGE_NAME}"
*/
export function createImageMap(values: string): SageMakerImageRepoMap[] {
    const valuesList = values.split(',')

    if (valuesList.length % 2 !== 0) {
        throw new Error(
            `SageMakerImageRepoMap maps a SageMaker Image to an ECR repo. Cannot be done with odd number of inputs. Found ${valuesList.length}.`
        )
    }

    const imageRepoMap: SageMakerImageRepoMap[] = []
    for (let i = 0; i < valuesList.length; i += 2) {
        const firstValue = valuesList[i].trim()
        const secondValue = valuesList[i + 1].trim()

        if (firstValue && secondValue) {
            imageRepoMap.push({
                ecrRepoArn: firstValue,
                sageMakerImageName: secondValue,
            })
        } else {
            throw new Error(
                `There is an empty value in the SageMakerImageMap. This is invalid`
            )
        }
    }

    return imageRepoMap
}

export function getImageNames(values: string): string[] {
    const valuesList = values.split(',')

    if (valuesList.length % 2 !== 0) {
        throw new Error(
            `SageMakerImageRepoMap maps a SageMaker Image to an ECR repo. Cannot be done with odd number of inputs. Found ${valuesList.length}.`
        )
    }

    const sageMakerImageNames: string[] = []
    for (let i = 0; i < valuesList.length; i += 2) {
        const name = valuesList[i + 1].trim()

        if (name) {
            sageMakerImageNames.push(name)
        } else {
            throw new Error(
                `There is an empty value in the SageMakerImageMap. This is invalid`
            )
        }
    }

    return sageMakerImageNames
}
