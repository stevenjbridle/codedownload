import * as cdk from 'aws-cdk-lib'
import { Construct } from 'constructs'
import * as iam from 'aws-cdk-lib/aws-iam'
import defaultUserConfig from '../config/default-user-settings.json'

export interface SageMakerRolesProps extends cdk.StackProps {
    // App launches will be restricted to only use ImageVersions within these SageMaker Images
    // Optional as not required when props.restricted=false. A check is performed in the constructor to validate
    // this field is provided when props.restricted=true
    sageMakerImageNames?: string[]
    mlflowFullAccessPolicy?: iam.ManagedPolicy
    mlflowReadOnlyAccessPolicy?: iam.ManagedPolicy
    restricted: boolean
    sharedS3Arn?: string
    teamName?: string
}

/*
Each Role in this stack has two conceptual properties: Restricted/Unrestricted, FullAccess/ReadOnly

Restricted/Unrestricted: Pertains to whether restriction on access to specific resources within a SageMaker API call is applied.
                         E.g., restrict the images available to a sagemaker:CreateApp call

FullAccess/ReadOnly: Pertains to the SageMaker API calls available (currently only support FullAccess and ReadOnly, as
                     these are natively supported Managed Policies

A Role can have either of these properties and will have certain Policies applied depending on the value of each property

This framework can be extended/modified for other Role types
*/
export class SageMakerRoles extends cdk.Stack {
    public readonly sageMakerFullAccessRestrictedUserExecutionRole:
        | iam.Role
        | undefined
    public readonly sageMakerReadOnlyRestrictedUserExecutionRole:
        | iam.Role
        | undefined
    public readonly sageMakerFullAccessUnrestrictedUserExecutionRole:
        | iam.Role
        | undefined
    public readonly sageMakerReadOnlyUnrestrictedUserExecutionRole:
        | iam.Role
        | undefined

    constructor(scope: Construct, id: string, props: SageMakerRolesProps) {
        super(scope, id, props)

        if (props.restricted) {
            if (!props.sageMakerImageNames) {
                throw new Error(
                    'Restricted option requires props.sageMakerImageNames to be set.'
                )
            }

            if (!props.sharedS3Arn) {
                throw new Error(
                    'Restricted option requires props.sharedS3Arn to be set.'
                )
            }

            if (!props.teamName) {
                throw new Error(
                    'Restricted option requires props.teamName to be set.'
                )
            }

            // Create base User Roles and set appropriate managed Policies
            this.sageMakerFullAccessRestrictedUserExecutionRole = new iam.Role(
                this,
                'SageMakerFullAccessRestrictedUserExecutionRole',
                {
                    assumedBy: new iam.ServicePrincipal(
                        'sagemaker.amazonaws.com'
                    ),
                }
            )

            this.sageMakerFullAccessRestrictedUserExecutionRole.addManagedPolicy(
                iam.ManagedPolicy.fromAwsManagedPolicyName(
                    'AmazonSageMakerFullAccess'
                )
            )

            this.sageMakerReadOnlyRestrictedUserExecutionRole = new iam.Role(
                this,
                'SageMakerReadOnlyRestrictedUserExecutionRole',
                {
                    assumedBy: new iam.ServicePrincipal(
                        'sagemaker.amazonaws.com'
                    ),
                }
            )

            this.sageMakerReadOnlyRestrictedUserExecutionRole.addManagedPolicy(
                iam.ManagedPolicy.fromAwsManagedPolicyName(
                    'AmazonSageMakerReadOnly'
                )
            )

            //this.sageMakerReadOnlyRestrictedUserExecutionRole.addToPolicy(
            //    mlflowAccessPolicy
            //)

            // Apply common Policies to restricted User Roles
            const sageMakerRestrictedUserExecutionRoles = [
                this.sageMakerFullAccessRestrictedUserExecutionRole,
                this.sageMakerReadOnlyRestrictedUserExecutionRole, // Only doing full access for ease of testing purposes
            ]

            const allowedImages: string[] = []

            // If we are in this block, we know props.sageMakerImageNames exists
            props.sageMakerImageNames!.forEach((imageName) => {
                allowedImages.push(`arn:aws:sagemaker:*:*:image/${imageName}`)
            })

            const restrictStudioToCustomImage = new iam.PolicyStatement({
                actions: ['sagemaker:CreateApp'],
                effect: iam.Effect.DENY,
                resources: ['*'],
                conditions: {
                    'ForAllValues:StringNotLike': {
                        'sagemaker:ImageArns': allowedImages,
                    },
                    'ForAllValues:StringLike': {
                        'sagemaker:InstanceTypes':
                            defaultUserConfig.StudioWebPortalSettings
                                .HiddenInstanceTypes,
                    },
                },
            })

            // TODO: Perhaps all actions should not be granted, following off blog post
            // https://aws.amazon.com/blogs/security/writing-iam-policies-grant-access-to-user-specific-folders-in-an-amazon-s3-bucket/
            const restrictAccessToTeamS3Prefix = new iam.PolicyStatement({
                effect: iam.Effect.ALLOW,
                actions: [
                    's3:DeleteObject',
                    's3:DeleteObjectTagging',
                    's3:DeleteObjectVersion',
                    's3:DeleteObjectVersionTagging',
                    's3:GetObject',
                    's3:GetObjectTagging',
                    's3:GetObjectVersion',
                    's3:GetObjectVersionTagging',
                    's3:ListBucket',
                    's3:PutObject',
                    's3:PutObjectTagging',
                    's3:PutObjectVersionTagging',
                    's3:RestoreObject',
                ],
                resources: [
                    props.sharedS3Arn!.concat('/', props.teamName),
                    props.sharedS3Arn!.concat('/', props.teamName!, '/*'),
                ],
            })

            const restrictAccessToS3 = new iam.PolicyStatement({
                effect: iam.Effect.DENY,
                actions: ['s3:*'],
                notResources: [
                    props.sharedS3Arn!,
                    props.sharedS3Arn!.concat('/', props.teamName!),
                    props.sharedS3Arn!.concat('/', props.teamName!, '/*'),
                ],
            })

            const restrictAccessToS3Base = new iam.PolicyStatement({
                effect: iam.Effect.DENY,
                actions: ['s3:ListBucket'],
                resources: [props.sharedS3Arn!],
                conditions: {
                    StringNotLike: {
                        's3:prefix': [
                            props.teamName!,
                            props.teamName!.concat('/*'),
                        ],
                    },
                },
            })

            // Give access to full access role to the shared s3
            this.sageMakerFullAccessRestrictedUserExecutionRole.addToPolicy(
                restrictAccessToTeamS3Prefix
            )

            this.sageMakerFullAccessRestrictedUserExecutionRole.addToPolicy(
                restrictAccessToS3
            )
            this.sageMakerFullAccessRestrictedUserExecutionRole.addToPolicy(
                restrictAccessToS3Base
            )

            //TODO for some reason, am still allowed to do full access s3 operations to ALL buckets instead of just the specified one.

            sageMakerRestrictedUserExecutionRoles.forEach((role) => {
                // Launching SageMaker Studio fails without being able to set source identity
                role.assumeRolePolicy!.addStatements(
                    new iam.PolicyStatement({
                        actions: ['sts:SetSourceIdentity'],
                        principals: [
                            new iam.ServicePrincipal('sagemaker.amazonaws.com'),
                        ],
                    })
                )

                // Studio Users will only be able to launch apps with images defined in this Policy
                role.addToPolicy(restrictStudioToCustomImage)

                // TODO: implement access denial for all resources hidden from the UI (instance types etc)
            })

            // Apply relevant FullAccess/ReadOnly Policies
            if (props.mlflowFullAccessPolicy) {
                this.sageMakerFullAccessRestrictedUserExecutionRole.addManagedPolicy(
                    props.mlflowFullAccessPolicy
                )
            }
            if (props.mlflowReadOnlyAccessPolicy) {
                this.sageMakerReadOnlyRestrictedUserExecutionRole.addManagedPolicy(
                    props.mlflowReadOnlyAccessPolicy
                )
            }
        } else {
            // Create base User Roles and set appropriate managed Policies
            this.sageMakerFullAccessUnrestrictedUserExecutionRole =
                new iam.Role(
                    this,
                    'SageMakerFullAccessUnrestrictedUserExecutionRole',
                    {
                        assumedBy: new iam.ServicePrincipal(
                            'sagemaker.amazonaws.com'
                        ),
                    }
                )

            this.sageMakerFullAccessUnrestrictedUserExecutionRole.addManagedPolicy(
                iam.ManagedPolicy.fromAwsManagedPolicyName(
                    'AmazonSageMakerFullAccess'
                )
            )

            this.sageMakerReadOnlyUnrestrictedUserExecutionRole = new iam.Role(
                this,
                'SageMakerReadOnlyUnrestrictedUserExecutionRole',
                {
                    assumedBy: new iam.ServicePrincipal(
                        'sagemaker.amazonaws.com'
                    ),
                }
            )

            this.sageMakerReadOnlyUnrestrictedUserExecutionRole.addManagedPolicy(
                iam.ManagedPolicy.fromAwsManagedPolicyName(
                    'AmazonSageMakerReadOnly'
                )
            )

            //this.sageMakerReadOnlyUnrestrictedUserExecutionRole.addToPolicy(
            //    mlflowAccessPolicy
            //)

            // Apply common Policies to unrestricted User Roles
            const sageMakerUnrestrictedUserExecutionRoles = [
                this.sageMakerFullAccessUnrestrictedUserExecutionRole,
                this.sageMakerReadOnlyUnrestrictedUserExecutionRole,
            ]

            sageMakerUnrestrictedUserExecutionRoles.forEach((role) => {
                // Launching SageMaker Studio fails without being able to set source identity
                role.assumeRolePolicy!.addStatements(
                    new iam.PolicyStatement({
                        actions: ['sts:SetSourceIdentity'],
                        principals: [
                            new iam.ServicePrincipal('sagemaker.amazonaws.com'),
                        ],
                    })
                )

                // TODO: implement access denial for all resources hidden from the UI (instance types etc). is this different
                // than for restricted users?
            })

            // Apply relevant FullAccess/ReadOnly Policies
            if (props.mlflowFullAccessPolicy) {
                this.sageMakerFullAccessUnrestrictedUserExecutionRole.addManagedPolicy(
                    props.mlflowFullAccessPolicy
                )
            }
            if (props.mlflowReadOnlyAccessPolicy) {
                this.sageMakerReadOnlyUnrestrictedUserExecutionRole.addManagedPolicy(
                    props.mlflowReadOnlyAccessPolicy
                )
            }
        }
    }
}
