import * as cdk from 'aws-cdk-lib'
import { Construct } from 'constructs'
import * as s3 from 'aws-cdk-lib/aws-s3'
import { RemovalPolicy } from 'aws-cdk-lib'
import * as iam from 'aws-cdk-lib/aws-iam'
//import { iam } from 'cdk-nag/lib/rules'

export class SageMakerS3 extends cdk.Stack {
    public readonly sharedS3Arn: string

    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
        super(scope, id, props)

        // TODO: Find out exact requirements for how data should be stored in s3
        const sharedS3 = new s3.Bucket(this, 'SharedS3', {
            blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
            encryption: s3.BucketEncryption.S3_MANAGED,
            enforceSSL: true,
            versioned: true,
            removalPolicy: RemovalPolicy.RETAIN,
        })

        // const bucketPolicy = new iam.PolicyStatement({
        //     actions: ['s3:*'],
        //     effect: iam.Effect.ALLOW,
        //     resources: [sharedS3.bucketArn, `${sharedS3.bucketArn}/*`],
        //     conditions: {
        //         'ForAllValues:StringEquals': {
        //             'aws:SourceAccount': '918473058104',
        //         },
        //     },
        // })

        // sharedS3.addToResourcePolicy(bucketPolicy)

        this.sharedS3Arn = sharedS3.bucketArn

        new cdk.CfnOutput(this, 'SharedS3Arn', {
            value: this.sharedS3Arn,
        })
    }
}
