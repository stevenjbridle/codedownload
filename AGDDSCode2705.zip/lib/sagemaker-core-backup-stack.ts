import * as dynamodb from 'aws-cdk-lib/aws-dynamodb'
import * as cdk from 'aws-cdk-lib'
import { Construct } from 'constructs'
import * as backup from 'aws-cdk-lib/aws-backup'
import * as iam from 'aws-cdk-lib/aws-iam'

export interface SageMakerCoreBackupProps extends cdk.StackProps {
    sagemakerUserDBTableName: string
    sagemakerUserDBTablePK: string
    sagemakerUserDBTableSK: string
}

export class SageMakerCoreBackup extends cdk.Stack {
    constructor(scope: Construct, id: string, props: SageMakerCoreBackupProps) {
        super(scope, id, props)

        const sagemakerUserDBTable = new dynamodb.TableV2(
            this,
            'SagemakerUserDBTable',
            {
                tableName: props.sagemakerUserDBTableName,
                partitionKey: {
                    name: props.sagemakerUserDBTablePK,
                    type: dynamodb.AttributeType.STRING,
                },
                sortKey: {
                    name: props.sagemakerUserDBTableSK,
                    type: dynamodb.AttributeType.STRING,
                },
            }
        )

        // ===== Sagemaker EFS Backup ===== //

        // TODO: Find out requirements for the backup vault, likely want to set the blockRecoveryPointDeletion set to true and also lock configuration
        const sageMakerEFSBackupVault = new backup.BackupVault(
            this,
            'SageMakerEFSBackupVault',
            {
                blockRecoveryPointDeletion: false,
            }
        )

        // TODO: Find out requirements for the backup plan
        const sagemakerEFSBackupPlan = backup.BackupPlan.daily35DayRetention(
            this,
            'SageMakerEFSBackupPlan',
            sageMakerEFSBackupVault
        )

        const efsBackupRole = new iam.Role(this, 'SageMakerEFSBackupRole', {
            assumedBy: new iam.ServicePrincipal('backup.amazonaws.com'),
        })

        // TODO: Overly permissive?
        efsBackupRole.addManagedPolicy(
            iam.ManagedPolicy.fromAwsManagedPolicyName(
                'AmazonElasticFileSystemFullAccess'
            )
        )

        new cdk.CfnOutput(this, 'SageMakerEFSBackupPlanId', {
            value: sagemakerEFSBackupPlan.backupPlanId,
        })

        new cdk.CfnOutput(this, 'SageMakerEFSBackupRoleARN', {
            value: efsBackupRole.roleArn,
        })
    }
}
