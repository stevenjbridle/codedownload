import * as cdk from 'aws-cdk-lib'
import { Construct } from 'constructs'
import * as iam from 'aws-cdk-lib/aws-iam'
import * as s3 from 'aws-cdk-lib/aws-s3'
import * as sagemaker from 'aws-cdk-lib/aws-sagemaker'
import { NagSuppressions } from 'cdk-nag'

export interface SageMakerMlflowProps extends cdk.StackProps {
    automaticModelRegistration: boolean
    mlflowVersion: string // e.g. '2.16'
    trackingServerSize: string // e.g. 'Small'
}

export class SageMakerMlflow extends cdk.Stack {
    public readonly mlflowApiReadOnlyAccessPolicy: iam.ManagedPolicy
    public readonly mlflowApiFullAccessPolicy: iam.ManagedPolicy
    public readonly mlflowTrackingServerArn: string

    constructor(scope: Construct, id: string, props: SageMakerMlflowProps) {
        super(scope, id, props)

        const mlflowArtifactStoreBucket = new s3.Bucket(
            this,
            'MlflowArtifactStoreBucket',
            {}
        )

        // ensure compliance with cdk-nag
        mlflowArtifactStoreBucket.addToResourcePolicy(
            new iam.PolicyStatement({
                actions: ['s3:*'],
                resources: [
                    mlflowArtifactStoreBucket.bucketArn,
                    mlflowArtifactStoreBucket.arnForObjects('*'),
                ],
                principals: [new iam.AnyPrincipal()],
                effect: iam.Effect.DENY,
                conditions: {
                    Bool: { 'aws:SecureTransport': 'false' },
                },
            })
        )

        NagSuppressions.addResourceSuppressions(mlflowArtifactStoreBucket, [
            {
                id: 'AwsSolutions-S1',
                reason: 'No S3 server access logs bucket in sandpit account. Not required.',
            },
        ])

        const mlflowTrackingServerRole = new iam.Role(
            this,
            'mlflowTrackingServerRole',
            { assumedBy: new iam.ServicePrincipal('sagemaker.amazonaws.com') }
        )

        mlflowArtifactStoreBucket.grantReadWrite(mlflowTrackingServerRole)
        mlflowTrackingServerRole.addManagedPolicy(
            iam.ManagedPolicy.fromAwsManagedPolicyName(
                'AmazonSageMakerModelRegistryFullAccess'
            )
        )

        const mlflowTrackingServer = new sagemaker.CfnMlflowTrackingServer(
            this,
            'mlflowTrackingServer',
            {
                artifactStoreUri: `s3://${mlflowArtifactStoreBucket.bucketName}`,
                automaticModelRegistration: props.automaticModelRegistration,
                mlflowVersion: props.mlflowVersion,
                roleArn: mlflowTrackingServerRole.roleArn,
                trackingServerName: `${this.stackName}TrackingServer`,
                trackingServerSize: props.trackingServerSize,
            }
        )

        this.mlflowTrackingServerArn =
            mlflowTrackingServer.attrTrackingServerArn

        this.mlflowApiFullAccessPolicy = new iam.ManagedPolicy(
            this,
            'MlflowApiFullAccessPolicy',
            {
                statements: [
                    new iam.PolicyStatement({
                        // IAM actions supported: https://docs.aws.amazon.com/sagemaker/latest/dg/mlflow-create-tracking-server-iam.html#mlflow-create-tracking-server-update-iam-actions
                        actions: ['sagemaker-mlflow:*'],
                        resources: [this.mlflowTrackingServerArn],
                    }),
                ],
            }
        )

        this.mlflowApiReadOnlyAccessPolicy = new iam.ManagedPolicy(
            this,
            'MlflowApiReadOnlyPolicy',
            {
                statements: [
                    new iam.PolicyStatement({
                        // IAM actions supported: https://docs.aws.amazon.com/sagemaker/latest/dg/mlflow-create-tracking-server-iam.html#mlflow-create-tracking-server-update-iam-actions
                        actions: [
                            // not tested whether these actions provide complete read only, or more than read only
                            'sagemaker:CreatePresignedMlflowTrackingServerUrl',
                            'sagemaker-mlflow:AccessUI',
                            'sagemaker-mlflow:Search*',
                            'sagemaker-mlflow:Get*',
                        ],
                        resources: [this.mlflowTrackingServerArn],
                    }),
                ],
            }
        )
    }
}
