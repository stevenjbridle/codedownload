import * as cdk from 'aws-cdk-lib'
import { Construct } from 'constructs'
import * as sagemaker from 'aws-cdk-lib/aws-sagemaker'
import * as ec2 from 'aws-cdk-lib/aws-ec2'
import * as ssm from 'aws-cdk-lib/aws-ssm'
import { vpc } from 'cdk-nag/lib/rules'
//import { efs } from 'cdk-nag/lib/rules'

export interface SageMakerProps extends cdk.StackProps {
    sageMakerImageNames?: string[]
    domainIDSsmParameterName: string
    efsIDSsmParameterName: string
    userExecutionRoleArn: string
    restricted: boolean
    vpcId: string
    endpointAccessSecurityGroupId: string
    sageMakerDomainSecurityGroupId: string
}

export class SageMakerCore extends cdk.Stack {
    public readonly domainId: string

    constructor(scope: Construct, id: string, props: SageMakerProps) {
        super(scope, id, props)

        const sageMakerVpc = ec2.Vpc.fromLookup(this, 'SageMakerVPCLookup', {
            vpcId: props.vpcId,
        })

        const endpointAccessSecurityGroup = ec2.SecurityGroup.fromLookupById(
            this,
            'SageMakerEndpointAccessSecurityGroup',
            props.endpointAccessSecurityGroupId
        )

        const domainSecurityGroup = ec2.SecurityGroup.fromLookupById(
            this,
            'SageMakerDomainSecurityGroup',
            props.sageMakerDomainSecurityGroupId
        )

        const sageMakerVpcSubnets = sageMakerVpc.selectSubnets({
            subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
        })

        const customImages:
            | cdk.aws_sagemaker.CfnDomain.CustomImageProperty[]
            | undefined = []

        if (props.sageMakerImageNames) {
            const studioAppImageConfig = new sagemaker.CfnAppImageConfig(
                this,
                'studioAppImageConfig',
                {
                    appImageConfigName: `StudioAppImageConfig-${this.stackName}`,
                    codeEditorAppImageConfig: {
                        containerConfig: {
                            containerEnvironmentVariables: [
                                {
                                    key: 'FOO',
                                    value: 'bar',
                                },
                            ],
                        },
                    },
                }
            )

            // This can support an arbitrary number of custom images, but only if those images all share the same CfnAppImageConfig
            // If different images require different CfnAppImageConfigs this will require restructuring. Support for that has
            // been deferred as it may not be required
            props.sageMakerImageNames.forEach((imageName) => {
                customImages.push({
                    appImageConfigName: studioAppImageConfig.appImageConfigName,
                    imageName: imageName,
                })
            })
        }

        let appNetworkAccessType = 'VpcOnly'

        // TODO: VPC setup for unrestricted environment
        if (!props.restricted) {
            appNetworkAccessType = 'PublicInternetOnly'
        }

        const sageMakerDomain = new sagemaker.CfnDomain(
            this,
            'SageMakerDomain',
            {
                appNetworkAccessType: appNetworkAccessType,
                authMode: 'IAM',
                domainName: `${this.stackName}`,
                defaultUserSettings: {
                    executionRole: props.userExecutionRoleArn,
                    securityGroups: [props.endpointAccessSecurityGroupId],
                    codeEditorAppSettings: {
                        customImages: customImages,
                    },
                    studioWebPortalSettings: {},
                },
                domainSettings: {
                    securityGroupIds: [props.sageMakerDomainSecurityGroupId],
                    // TODO: leverage sts:SourceIdentity to manage user execution role
                    executionRoleIdentityConfig: 'USER_PROFILE_NAME',
                },

                vpcId: sageMakerVpc.vpcId,
                subnetIds: sageMakerVpcSubnets.subnetIds,
            }
        )

        this.domainId = sageMakerDomain.attrDomainId

        // ===== SSM parameter upload required for efs backup stack ===== //

        const sageMakerDomainIDUpload = new ssm.StringParameter(
            this,
            'DOMAINID',
            {
                parameterName: props.domainIDSsmParameterName,
                stringValue: sageMakerDomain.attrDomainId,
            }
        )

        const sageMakerEFSIDUpload = new ssm.StringParameter(this, 'EFSID', {
            parameterName: props.efsIDSsmParameterName,
            stringValue: sageMakerDomain.attrHomeEfsFileSystemId,
        })

        new cdk.CfnOutput(this, 'sageMakerEFSID', {
            value: sageMakerDomain.attrHomeEfsFileSystemId,
        })

        new cdk.CfnOutput(this, 'DomainId', {
            key: 'DomainId',
            value: sageMakerDomain.attrDomainId,
        })
    }
}
