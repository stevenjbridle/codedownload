import * as cdk from 'aws-cdk-lib'
import { Construct } from 'constructs'
import * as sagemaker from 'aws-cdk-lib/aws-sagemaker'
import * as ec2 from 'aws-cdk-lib/aws-ec2'
import * as ssm from 'aws-cdk-lib/aws-ssm'
//import { efs } from 'cdk-nag/lib/rules'

export class SageMakerVpc extends cdk.Stack {
    public readonly domainId: string

    constructor(scope: Construct, id: string, props?: cdk.StackProps) {
        super(scope, id, props)

        // TODO: create VPC infra in a separate stack
        // initial networking setup
        const sageMakerVpc = new ec2.Vpc(this, 'SageMakerVpc', {
            maxAzs: 1,
            subnetConfiguration: [
                {
                    name: 'sageMakerIsolated',
                    subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
                },
            ],
        })

        const sageMakerVpcSubnets = sageMakerVpc.selectSubnets({
            subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
        })

        const vpcInterfaceEndpointServices = [
            ec2.InterfaceVpcEndpointAwsService.SAGEMAKER_API,
            ec2.InterfaceVpcEndpointAwsService.SAGEMAKER_RUNTIME,
            ec2.InterfaceVpcEndpointAwsService.SAGEMAKER_STUDIO,
            ec2.InterfaceVpcEndpointAwsService.SERVICE_CATALOG,
            ec2.InterfaceVpcEndpointAwsService.SAGEMAKER_EXPERIMENTS,
            //ec2.InterfaceVpcEndpointAwsService.EVENTBRIDGE,
        ]

        let endpointSecurityGroups: string[] = []

        // create each interface endpoint and a corresponding security group that allows inbound from VPC subnets
        // build a list of these security groups to create egress rules for resources to access these endpoints later
        vpcInterfaceEndpointServices.forEach((service) => {
            let serviceName = `${service.shortName}`
            let securityGroup = new ec2.SecurityGroup(this, serviceName, {
                vpc: sageMakerVpc,
                allowAllOutbound: false,
            })
            sageMakerVpcSubnets.subnets.forEach((subnet) =>
                securityGroup.addIngressRule(
                    ec2.Peer.ipv4(subnet.ipv4CidrBlock),
                    ec2.Port.HTTPS
                )
            )
            sageMakerVpc.addInterfaceEndpoint(`${service.shortName}`, {
                service: service,
                securityGroups: [securityGroup],
            })

            endpointSecurityGroups.push(securityGroup.securityGroupId)
        })

        // now we know each SG associated with a required interface endpoint, create an SG that allows egress to
        // resources with these ids
        const endpointAccessSecurityGroup = new ec2.SecurityGroup(
            this,
            'EndpointAccessSecurityGroup',
            {
                vpc: sageMakerVpc,
                allowAllOutbound: false,
            }
        )

        // TODO: domain sg hardening
        const sageMakerDomainSecurityGroup = new ec2.SecurityGroup(
            this,
            'sageMakerDomainSecurityGroup',
            { vpc: sageMakerVpc }
        )

        endpointSecurityGroups.forEach((sgId) =>
            endpointAccessSecurityGroup.addEgressRule(
                ec2.Peer.securityGroupId(sgId),
                ec2.Port.HTTPS
            )
        )

        sageMakerVpc.addGatewayEndpoint(`vpcEndpoint-s3`, {
            service: ec2.GatewayVpcEndpointAwsService.S3,
        })
        sageMakerVpc.addGatewayEndpoint(`vpcEndpoint-dynamodb`, {
            service: ec2.GatewayVpcEndpointAwsService.DYNAMODB,
        })

        // TODO: implement this when released
        // fromLookup added in https://github.com/aws/aws-cdk/pull/33619 but not yet released
        // add manually after deployment for now
        endpointAccessSecurityGroup.addEgressRule(
            ec2.Peer.prefixList(
                ec2.PrefixList.fromLookup(this, 's3', {
                    prefixListName: `com.amazonaws.${props?.env?.region}.s3`,
                }).prefixListId
            ),
            ec2.Port.HTTPS
        )

        new cdk.CfnOutput(this, 'VpcId', {
            value: sageMakerVpc.vpcId,
        })

        new cdk.CfnOutput(this, 'EndpointAccessSecurityGroupId', {
            value: endpointAccessSecurityGroup.securityGroupId,
        })
        new cdk.CfnOutput(this, 'DomainSecurityGroupId', {
            value: sageMakerDomainSecurityGroup.securityGroupId,
        })
    }
}
