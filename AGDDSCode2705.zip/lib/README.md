# SageMaker Stacks

SageMaker SSO Auth mode doesn't provide native support for multiple User Roles in a given Domain. It is possible, but would require a bespoke solution using EventBridge and Lambda to update Roles as Users are created.

Instead, we may deploy a multi-Domain solution to support multiple tenants of varying Role requirements. Separating out the stacks as done in this folder supports a multi-Domain solution.
