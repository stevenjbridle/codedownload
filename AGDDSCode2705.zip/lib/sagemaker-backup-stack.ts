import * as dynamodb from 'aws-cdk-lib/aws-dynamodb'
import * as cdk from 'aws-cdk-lib'
import { Construct } from 'constructs'
import * as backup from 'aws-cdk-lib/aws-backup'
import * as efs from 'aws-cdk-lib/aws-efs'
import * as ssm from 'aws-cdk-lib/aws-ssm'
import * as ec2 from 'aws-cdk-lib/aws-ec2'
import * as events from 'aws-cdk-lib/aws-events'
import * as lambda from 'aws-cdk-lib/aws-lambda'
import * as targets from 'aws-cdk-lib/aws-events-targets'
import { execSync } from 'child_process'
import * as iam from 'aws-cdk-lib/aws-iam'
import { vpc } from 'cdk-nag/lib/rules'

//TODO: Move vpc param from the domain info into the stack props
export interface SageMakerBackupProps extends cdk.StackProps {
    sagemakerUserDBTableName: string
    sagemakerUserDBTablePK: string
    sagemakerUserDBTableSK: string
    sagemakerVpcId: string
}

export interface SageMakerDomainInfo {
    domainIdParamName: string
    efsIdSsmParamName: string
}

export class SageMakerBackup extends cdk.Stack {
    constructor(scope: Construct, id: string, props: SageMakerBackupProps) {
        super(scope, id, props)

        const sageMakerVpcConcrete = ec2.Vpc.fromLookup(this, 'VPC', {
            vpcId: props.sagemakerVpcId,
        })

        /*
        TODO: Remove this backup and convert to a combination of api calls:

        1) aws efs describe-file-systems - match all instances of the file system id's and extract the ARN's
        https://docs.aws.amazon.com/cli/latest/reference/efs/describe-file-systems.html
        
        2) apply backup with the create-backup-selection using the ARN's from the previous step
        https://docs.aws.amazon.com/cli/latest/reference/backup/create-backup-selection.html

        props.sagemakerDomainInfos.forEach((domainInfo) => {
            const efsID = ssm.StringParameter.valueForStringParameter(
                this,
                domainInfo.efsIdSsmParamName
            )

            const domainID = ssm.StringParameter.valueForStringParameter(
                this,
                domainInfo.domainIdParamName
            )

            // This is the reason for a new stack, this would result in a 'arguments must be concrete' error
            const efsSecurityGroup = ec2.SecurityGroup.fromLookupByName(
                this,
                `SG-${domainID}`,
                `security-group-for-inbound-nfs-${domainID}`,
                sageMakerVpcConcrete
            )

            // The name of the secuirty group was found by creating a sagemaker domain and seing the resulting structre of the security group name
            const importedEfsFilesystem =
                efs.FileSystem.fromFileSystemAttributes(
                    this,
                    `ImportedEFS-${efsID}`,
                    {
                        fileSystemId: efsID,
                        securityGroup: efsSecurityGroup,
                    }
                )

            // Apply backup plan to the sagemaker efs
            sagemakerEFSBackupPlan.addSelection(`BackupPlan-${efsID}`, {
                resources: [
                    backup.BackupResource.fromEfsFileSystem(
                        importedEfsFilesystem
                    ),
                ],
            })
        })
        */

        // Defining environmental variables
        const lambdaFunctionName = 'UserEventHandlerUpdate'

        type TEnv = {
            [dict_key: string]: string
        }

        const lambdaEnv: TEnv = {
            tableName: props.sagemakerUserDBTableName,
            tablePK: props.sagemakerUserDBTablePK,
            tableSK: props.sagemakerUserDBTableSK,
        }

        // Define lambda role
        // TODO: Role likely overly permissive
        const lambdaRole = new iam.Role(this, lambdaFunctionName + 'Role', {
            assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
            description: lambdaFunctionName + 'Lambda Function Role',
            roleName: lambdaFunctionName + 'LambdaFunctionRole',
            managedPolicies: [
                iam.ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'AmazonBasicExecutionRole',
                    'arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole'
                ),
                iam.ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'AmazonDynamoDBFullAccess',
                    'arn:aws:iam::aws:policy/AmazonDynamoDBFullAccess'
                ),
                // Required policy for lambda to execute in vpc
                iam.ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'VPCAccessExecutionRole',
                    'arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole'
                ),
                iam.ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'SagemakerReadOnlyRole',
                    'arn:aws:iam::aws:policy/AmazonSageMakerReadOnly'
                ),
            ],
        })

        const userEventHandler = new lambda.Function(this, lambdaFunctionName, {
            runtime: lambda.Runtime.PYTHON_3_13,
            architecture: lambda.Architecture.X86_64,
            handler: 'lambda-handler.lambda_handler',
            role: lambdaRole,
            environment: lambdaEnv,
            vpc: sageMakerVpcConcrete,
            code: lambda.Code.fromAsset('./lambda', {
                bundling: {
                    image: lambda.Runtime.PYTHON_3_13.bundlingImage,
                    command: ['pip install -r requirements.txt'],
                    // Build locally when using dev container to avoid issues with nested containers
                    local: {
                        tryBundle(outputDir: string) {
                            try {
                                execSync('pip3 --version')
                            } catch {
                                return false
                            }
                            const commands = [
                                `cd lambda`,
                                `pip3 install -r requirements.txt -t ${outputDir}`,
                                `cp -a . ${outputDir}`,
                            ]
                            execSync(commands.join(' && '))
                            return true
                        },
                    },
                },
            }),
        })

        // Rule to trigger lambda when a new sagemaker user is created
        const lambdaTriggerRule = new events.Rule(
            this,
            lambdaFunctionName + 'TriggerRule',
            {
                eventPattern: {
                    source: ['aws.sagemaker'],
                    detail: {
                        eventName: ['CreateUserProfile'],
                    },
                },
            }
        )

        lambdaTriggerRule.addTarget(
            new targets.LambdaFunction(userEventHandler)
        )
    }
}
