import * as efs from 'aws-cdk-lib/aws-efs'
import * as cdk from 'aws-cdk-lib'
import * as backup from 'aws-cdk-lib/aws-backup'
import * as ssm from 'aws-cdk-lib/aws-ssm'
import { Construct } from 'constructs'
import * as ec2 from 'aws-cdk-lib/aws-ec2'
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb'
import * as events from 'aws-cdk-lib/aws-events'
import * as lambda from 'aws-cdk-lib/aws-lambda'
import * as targets from 'aws-cdk-lib/aws-events-targets'
import { execSync } from 'child_process'
import * as iam from 'aws-cdk-lib/aws-iam'
import { sagemaker } from 'cdk-nag/lib/rules'

export interface SageMakerEFSProps extends cdk.StackProps {
    vpcIDSsmParameterName: string
    domainIDSsmParameterName: string
    efsIDSsmParameterName: string
}

export class SageMakerEfs extends cdk.Stack {
    constructor(scope: Construct, id: string, props: SageMakerEFSProps) {
        super(scope, id, props)

        // General Note:
        //      The reason for having a seperate stack for efs backup is because you are unable to import the
        //      efs file system created by sagemaker in the same stack that a sagemaker domain is defined.
        //      This is due to not being able to lookup the security group as it reuires a concrete vpc only satisfied
        //      by the 'fromLookup'.
        //      More info here: https://lzygo1995.medium.com/how-to-resolve-all-arguments-to-vpc-fromlookup-must-be-concrete-no-tokens-error-in-cdk-add1c2aba97b

        // ===== Import ID's from parameter store ===== //

        // CRITICAL NOTE:
        //      Once a stack is deployed via cdk, these values will be retreved from the cdk.context.json file.
        //      If you tare the stack down and redeploy, you must do a: cdk context --clear
        const vpcID = ssm.StringParameter.valueFromLookup(
            this,
            props.vpcIDSsmParameterName
        )

        const efsID = ssm.StringParameter.valueFromLookup(
            this,
            props.efsIDSsmParameterName
        )

        const domainID = ssm.StringParameter.valueFromLookup(
            this,
            props.domainIDSsmParameterName
        )

        const sageMakerVpcConcrete = ec2.Vpc.fromLookup(this, 'VPC', {
            vpcId: vpcID,
        })

        // This is the reason for a new stack, this would result in a 'arguments must be concrete' error
        const efsSecurityGroup = ec2.SecurityGroup.fromLookupByName(
            this,
            'SG',
            `security-group-for-inbound-nfs-${domainID}`,
            sageMakerVpcConcrete
        )

        // The name of the secuirty group was found by creating a sagemaker domain and seing the resulting structre of the security group name
        const importedEfsFilesystem = efs.FileSystem.fromFileSystemAttributes(
            this,
            'ImportedEFS',
            {
                fileSystemId: efsID,
                securityGroup: efsSecurityGroup,
            }
        )

        // ===== Sagemaker EFS Backup ===== //

        // TODO: Find out requirements for the backup plan
        const sageMakerEFSBackupPlan = backup.BackupPlan.daily35DayRetention(
            this,
            'SageMakerEFSBackupPlan'
        )

        // Apply backup plan to the sagemaker efs
        sageMakerEFSBackupPlan.addSelection('resoucesToBackupPlan', {
            resources: [
                backup.BackupResource.fromEfsFileSystem(importedEfsFilesystem),
            ],
        })

        // ===== Sagemaker to EFS POSIX user tracking ===== /

        // Table definitions
        const sagemakerUserDBTablePK = 'PrincipleID'
        const sagemakerUserDBTableSK = 'DomainID'

        const sagemakerUserDBTable = new dynamodb.TableV2(
            this,
            'SagemakerUserDBTable',
            {
                tableName: 'SagemakerStudioUser',
                partitionKey: {
                    name: sagemakerUserDBTablePK,
                    type: dynamodb.AttributeType.STRING,
                },
                sortKey: {
                    name: sagemakerUserDBTableSK,
                    type: dynamodb.AttributeType.STRING,
                },
            }
        )

        // Defining environmental variables
        const lambdaFunctionName = 'UserEventHandler'

        type TEnv = {
            [dict_key: string]: string
        }

        const lambdaEnv: TEnv = {
            tableName: sagemakerUserDBTable.tableName,
            tablePK: sagemakerUserDBTablePK,
            tableSK: sagemakerUserDBTableSK,
            efsID: efsID,
        }

        // Define lambda role
        // TODO: Role likely overly permissive
        const lambdaRole = new iam.Role(this, lambdaFunctionName + 'Role', {
            assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
            description: lambdaFunctionName + 'Lambda Function Role',
            roleName: lambdaFunctionName + 'LambdaFunctionRole',
            managedPolicies: [
                iam.ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'AmazonBasicExecutionRole',
                    'arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole'
                ),
                iam.ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'AmazonDynamoDBFullAccess',
                    'arn:aws:iam::aws:policy/AmazonDynamoDBFullAccess'
                ),
                // Required policy for lambda to execute in vpc
                iam.ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'VPCAccessExecutionRole',
                    'arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole'
                ),
                iam.ManagedPolicy.fromManagedPolicyArn(
                    this,
                    'SagemakerReadOnlyRole',
                    'arn:aws:iam::aws:policy/AmazonSageMakerReadOnly'
                ),
            ],
        })

        const userEventHandler = new lambda.Function(this, lambdaFunctionName, {
            runtime: lambda.Runtime.PYTHON_3_13,
            architecture: lambda.Architecture.X86_64,
            handler: 'lambda-handler.lambda_handler',
            role: lambdaRole,
            environment: lambdaEnv,
            vpc: sageMakerVpcConcrete,
            code: lambda.Code.fromAsset('./lambda', {
                bundling: {
                    image: lambda.Runtime.PYTHON_3_13.bundlingImage,
                    command: ['pip install -r requirements.txt'],
                    // Build locally when using dev container to avoid issues with nested containers
                    local: {
                        tryBundle(outputDir: string) {
                            try {
                                execSync('pip3 --version')
                            } catch {
                                return false
                            }
                            const commands = [
                                `cd lambda`,
                                `pip3 install -r requirements.txt -t ${outputDir}`,
                                `cp -a . ${outputDir}`,
                            ]
                            execSync(commands.join(' && '))
                            return true
                        },
                    },
                },
            }),
        })

        // Rule to trigger lambda when a new sagemaker user is created
        const lambdaTriggerRule = new events.Rule(
            this,
            lambdaFunctionName + 'TriggerRule',
            {
                eventPattern: {
                    source: ['aws.sagemaker'],
                    detail: {
                        eventName: ['CreateUserProfile'],
                    },
                },
            }
        )

        lambdaTriggerRule.addTarget(
            new targets.LambdaFunction(userEventHandler)
        )
    }
}
