import * as cdk from 'aws-cdk-lib'
import { Construct } from 'constructs'
import * as iam from 'aws-cdk-lib/aws-iam'
import * as sagemaker from 'aws-cdk-lib/aws-sagemaker'

export interface SageMakerImageRepoMap {
    // The ECR Repo ARN that contains images referenced by SageMaker Image Versions
    ecrRepoArn: string
    // App launches will be restricted to only use ImageVersions within this SageMaker Image
    sageMakerImageName: string
}

export interface SageMakerImageProps extends cdk.StackProps {
    sageMakerImages: SageMakerImageRepoMap[]
}

export class SageMakerImages extends cdk.Stack {
    constructor(scope: Construct, id: string, props: SageMakerImageProps) {
        super(scope, id, props)

        props.sageMakerImages.forEach((image) => {
            // A SageMaker Image requires a Role to access the ECR repo that SageMaker Image Versions reference
            const sageMakerImageRole = new iam.Role(
                this,
                `SageMakerImageRole-${image.sageMakerImageName}`,
                {
                    assumedBy: new iam.ServicePrincipal(
                        'sagemaker.amazonaws.com'
                    ),
                }
            )

            const allowSageMakerEcrAccess = new iam.PolicyStatement({
                effect: iam.Effect.ALLOW,
                actions: [
                    'ecr:GetAuthorizationToken',
                    'ecr:BatchCheckLayerAvailability',
                    'ecr:GetDownloadUrlForLayer',
                    'ecr:GetRepositoryPolicy',
                    'ecr:DescribeRepositories',
                    'ecr:ListImages',
                    'ecr:DescribeImages',
                    'ecr:BatchGetImage',
                ],
                resources: [image.ecrRepoArn],
            })

            const denyNonSageMakerEcrAccess = new iam.PolicyStatement({
                effect: iam.Effect.DENY,
                actions: ['ecr:*'],
                resources: ['*'],
                conditions: {
                    ArnNotEquals: {
                        'aws:ResourceArn': image.ecrRepoArn,
                    },
                },
            })

            // Deny access to all but the specified ECR repo
            sageMakerImageRole.addToPolicy(allowSageMakerEcrAccess)
            sageMakerImageRole.addToPolicy(denyNonSageMakerEcrAccess)

            const studioImage = new sagemaker.CfnImage(
                this,
                `StudioImage-${image.sageMakerImageName}`,
                {
                    imageName: image.sageMakerImageName,
                    imageRoleArn: sageMakerImageRole.roleArn,
                }
            )
        })
    }
}
