# Lambda

When a sagemaker domain is deployed, an elastic file system (EFS) is automatically provisioned. Additionally, when the domain is setup in SSO mode, a user logging into the domain for the first time will have a access point in the efs with security group applied, and sagemaker user profile created. However, in the event that a system restore is required, there is currently no way to attach existing EFS volume to a new sagemaker domain. The [SageMaker Studio Administration Best Practices](https://docs.aws.amazon.com/whitepapers/latest/sagemaker-studio-admin-best-practices/multiple-domains-and-shared-spaces.html) provides the following steps for a fully **_manual_** backup recovery procedure:

1. Create a new SageMaker AI Studio domain.
1. Create the user profiles and spaces.
1. For each user profile, copy over the files from the backup on EFS/Amazon S3.
1. Optionally, delete all apps and user profiles, on the old SageMaker AI Studio domain.

For more detailed backup process [see here](https://docs.aws.amazon.com/whitepapers/latest/sagemaker-studio-admin-best-practices/appendix.html#sagemaker-studio-domain-backup-and-recovery).

A fully **_automatic_** backup procedure described in a [AWS blog]("https://aws.amazon.com/blogs/machine-learning/implement-backup-and-recovery-using-an-event-driven-serverless-architecture-with-amazon-sagemaker-studio/) post is possible but was considered out of scope, hence a **_middle ground_** has been implemented. The middle ground in this case is maintaining a user mapping between the principle ID, sagemaker user ID, and the EFS ID. Additionally, as there might be multiple sagemaker domains in a single aws account with the same user having access to both domains, the sagemaker domain ID is also documented so that a mapping for each user is kept **_per domain_**.

The middle ground is achieved by triggering a lambda when a `CreateUserProfile` event is generated in cloudwatch depicted in the following diagram:

```mermaid
    sequenceDiagram
        title Creating user mapping flow
        participant Sagemaker
        participant CloudWatch
        participant Lambda
        participant DynamoDB


        Sagemaker->>CloudWatch: 'CreateUserProfile' event
        CloudWatch->>Lambda: Trigger lambda
        Lambda->>Sagemaker: describe_user_profile api call
        Sagemaker->>Lambda: describe_user_profile response
        Lambda->>DynamoDB: Push formatted data
```

The reason for needing the [describe user profile](https://docs.aws.amazon.com/sagemaker/latest/APIReference/API_DescribeUserProfile.html) api call is to get the `HomeEfsFileSystemUid` (POSIX User) attribute not present in the `CreateUserProfile` event.
