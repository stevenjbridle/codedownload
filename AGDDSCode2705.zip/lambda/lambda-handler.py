import boto3
import os
import json
from aws_lambda_powertools import Logger
from aws_lambda_powertools.utilities.typing import LambdaContext

dynamodb_client = boto3.client("dynamodb")
sagemaker_client = boto3.client("sagemaker")
table_name = os.environ.get("tableName")  # Env variable defined in stack
table_sk = os.environ.get("tableSK")  # Env variable defined in stack
table_pk = os.environ.get("tablePK")  # Env variable defined in stack

logger = Logger()

@logger.inject_lambda_context
def lambda_handler(event: dict, context: LambdaContext):

    principle_id = event["detail"]["userIdentity"]["principalId"]
    domain_id = event["detail"]["requestParameters"]["domainId"]
    sagemaker_user_id = event["detail"]["requestParameters"]["userProfileName"]

    # Get users POSIX id on the efs
    describe_user = sagemaker_client.describe_user_profile(
        DomainId=domain_id, UserProfileName=sagemaker_user_id
    )

    home_efs_file_system_uid = describe_user["HomeEfsFileSystemUid"]

    # Get efs file system id
    describe_domain = sagemaker_client.describe_domain(DomainId=domain_id)

    home_efs_file_system_id = describe_domain["HomeEfsFileSystemId"]

    item = {
        table_pk: {"S": principle_id},
        table_sk: {"S": domain_id},
        "SagemakerUserID": {"S": sagemaker_user_id},
        "FileSystemID": {"S": home_efs_file_system_id},
        "HomeEfsFileSystemUid": {"S": home_efs_file_system_uid},
    }
    # Upload details of the new user
    result = dynamodb_client.put_item(TableName=table_name, Item=item)
