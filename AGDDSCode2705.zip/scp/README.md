# Service Control Policy

The SCP in this folder is intended to ensure that

**for a given Role:** DataScientist

**that has access to:** the SageMaker SSO App, other AWS services

**the Role can:** only access SageMaker Studio (and associated resources) via the SageMaker SSO App, but can still access other AWS services they may require for their role

This is accomplished by:

-   restricting all access to SageMaker and SageMaker MLFlow for the Role (a different Role is assumed when in SageMaker Studio accessed via the SSO App)
-   restricting all access to the EFS Volume used by SageMaker Studio for the Role, via a ResourceTag

## TODO

-   consider other resources that may need to be restricted
-   consider restricting access to all resources with a tag unique to the resources deployed from this repo, as this may be a more scalable approach
