# Integ Test

Briefly attempted creating integration tests using the CDK alpha module. Currently not working, pivoted due to time constraints.

# Docs

https://docs.aws.amazon.com/cdk/api/v2/docs/integ-tests-alpha-readme.html

https://github.com/aws-samples/cdk-integ-tests-sample/tree/main

https://github.com/aws/aws-cdk-cli/tree/main/packages/%40aws-cdk/integ-runner
