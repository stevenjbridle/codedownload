import { App, PhysicalName } from 'aws-cdk-lib'
import { cloud_assembly_schema } from 'aws-cdk-lib'
import { IntegTest, ExpectedResult } from '@aws-cdk/integ-tests-alpha'
import { SageMakerCore } from '../../lib/sagemaker-core-stack'
import { SageMakerRoles } from '../../lib/sagemaker-roles-stack'
import { getBooleanEnvVar } from '../../helpers/boolean-environment-variables'
import { getUserExecutionRoleArns } from '../../helpers/get-user-execution-role-arns'

const VPC_SSM_PARAM_NAME = `/SageMaker/VPCID`
const DOMAIN_SSM_PARAM_NAME = `/SageMaker/DOMAINID`
const EFS_SSM_PARAM_NAME = `/SageMaker/EFSID`
const SAGEMAKER_IMAGE_NAMES = ['image1', 'image2']
const RESTRICTED_ENVIRONMENT = 'true'

const restricted = getBooleanEnvVar(RESTRICTED_ENVIRONMENT)

const app = new App()

const sageMakerRolesStack = new SageMakerRoles(app, 'SageMakerRoles', {
    env: {
        account: process.env.CDK_DEFAULT_ACCOUNT,
        region: process.env.CDK_DEFAULT_REGION,
    },
    sageMakerImageNames: SAGEMAKER_IMAGE_NAMES,
    restricted: restricted,
})

const sageMakerUserExecutionRoleArns: (string | undefined)[] =
    getUserExecutionRoleArns(sageMakerRolesStack, restricted)

const sageMakerCoreStack = new SageMakerCore(app, 'SageMakerCore', {
    env: {
        account: process.env.CDK_DEFAULT_ACCOUNT,
        region: process.env.CDK_DEFAULT_REGION,
    },
    vpcIDSsmParameterName: VPC_SSM_PARAM_NAME,
    domainIDSsmParameterName: DOMAIN_SSM_PARAM_NAME,
    efsIDSsmParameterName: EFS_SSM_PARAM_NAME,
    sageMakerImageNames: SAGEMAKER_IMAGE_NAMES,
    // Either of the FullAccess or ReadOnly Roles are suitable for this test, as both are created for a given restricted status
    userExecutionRoleArn: sageMakerUserExecutionRoleArns[0]!,
    // userExecutionRoleArn: PhysicalName.GENERATE_IF_NEEDED,
    restricted: restricted,
})

const testCase = new IntegTest(app, 'restrictedSettingIntegrationTest', {
    testCases: [sageMakerCoreStack],
    regions: ['ap-southeast-2'],
    cdkCommandOptions: {
        deploy: {
            args: {
                requireApproval: cloud_assembly_schema.RequireApproval.NEVER,
            },
        },
        destroy: {
            args: {
                force: true,
            },
        },
    },
})

const domainDescription = testCase.assertions.awsApiCall(
    'SageMaker',
    'describeDomain',
    {
        DomainId: sageMakerCoreStack.domainId,
    }
)

domainDescription.assertAtPath(
    'AppNetworkAccessType',
    ExpectedResult.stringLikeRegexp('VpcOnly')
)
