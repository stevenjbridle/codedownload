import { getBooleanEnvVar } from '../../helpers/boolean-environment-variables'
import { createImageMap, getImageNames } from '../../helpers/create-image-map'
import { SageMakerImageRepoMap } from '../../lib/sagemaker-image-stack'
import {
    getUserExecutionRoleInfo,
    UserExecutionRoleInfo,
} from '../../helpers/get-user-execution-role-info'
import { SageMakerRoles } from '../../lib/sagemaker-roles-stack'
import { App } from 'aws-cdk-lib'

describe('helpers/boolean-environment-variables', () => {
    test('Converts true', () => {
        expect(getBooleanEnvVar('true')).toBeTruthy
        expect(getBooleanEnvVar('True')).toBeTruthy
    })

    test('Converts false', () => {
        expect(getBooleanEnvVar('false')).toBeFalsy
        expect(getBooleanEnvVar('False')).toBeFalsy
    })

    test('Errors on non true/false input', () => {
        expect(() => getBooleanEnvVar('other')).toThrow(Error)
    })
})

describe('helpers/create-image-map', () => {
    test('Creates correct map', () => {
        let SAGEMAKER_IMAGE_MAP =
            'pair1value1,pair1value2 ,pair2value1, pair2value2'
        let expectedOutput: SageMakerImageRepoMap[] = [
            {
                ecrRepoArn: 'pair1value1',
                sageMakerImageName: 'pair1value2',
            },
            {
                ecrRepoArn: 'pair2value1',
                sageMakerImageName: 'pair2value2',
            },
        ]
        let output = createImageMap(SAGEMAKER_IMAGE_MAP)
        expect(output).toEqual(expectedOutput)
    })

    test('Errors on odd number of values', () => {
        let SAGEMAKER_IMAGE_MAP = 'pair1value1,pair1value2,pair2value1'

        expect(() => createImageMap(SAGEMAKER_IMAGE_MAP)).toThrow(Error)
    })

    test('Errors on empty value', () => {
        let SAGEMAKER_IMAGE_MAP = 'pair1value1,pair1value2, ,pair2value2'

        expect(() => createImageMap(SAGEMAKER_IMAGE_MAP)).toThrow(Error)
    })

    test('Get image names', () => {
        let SAGEMAKER_IMAGE_MAP =
            'pair1value1,pair1value2 ,pair2value1, pair2value2'
        let expectedOutput: string[] = ['pair1value2', 'pair2value2']
        let output = getImageNames(SAGEMAKER_IMAGE_MAP)
        expect(output).toEqual(expectedOutput)
    })
})

// Role ARNs are Tokens: https://docs.aws.amazon.com/cdk/v2/guide/tokens.html
// As such, additional metadata about the Role is created in this helper
describe('helpers/get-user-execution-role-info', () => {
    test('Restricted Roles', () => {
        let app = new App()
        let restricted = true
        let sageMakerRolesStack = new SageMakerRoles(app, 'SageMakerRoles', {
            sageMakerImageNames: ['exampleimage'],
            restricted: restricted,
            teamName: 'exampleTeam',
            sharedS3Arn: 'exampleS3Arn',
        })

        const roleInfoList: UserExecutionRoleInfo[] = getUserExecutionRoleInfo(
            sageMakerRolesStack,
            restricted
        )

        const areAllRestrictedRoles = roleInfoList.every(
            (roleInfo) => roleInfo.restricted === true
        )

        expect(areAllRestrictedRoles).toBe(true)
    })
    test('Unrestricted Roles', () => {
        let app = new App()
        let restricted = false
        let sageMakerRolesStack = new SageMakerRoles(app, 'SageMakerRoles', {
            restricted: restricted,
        })
        const roleInfoList: UserExecutionRoleInfo[] = getUserExecutionRoleInfo(
            sageMakerRolesStack,
            restricted
        )

        const areAllUnrestrictedRoles = roleInfoList.every(
            (roleInfo) => roleInfo.restricted === false
        )

        expect(areAllUnrestrictedRoles).toBe(true)
    })
})
