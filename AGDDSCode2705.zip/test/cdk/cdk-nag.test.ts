import * as cdk from 'aws-cdk-lib'
import { Match, Annotations } from 'aws-cdk-lib/assertions'
import { SageMakerCore } from '../../lib/sagemaker-core-stack'
import { AwsSolutionsChecks } from 'cdk-nag'
import { Aspects } from 'aws-cdk-lib'

describe('cdk-nag compliance of stack: AwsSolutions Pack', () => {
    // TODO: Update after separating out stacks
    /*
    let app = new cdk.App()
    let stackProps = {
        vpcIDSsmParameterName:
            process.env.VPC_SSM_PARAM_NAME ?? `/SageMaker/VPCID`,
        domainIDSsmParameterName:
            process.env.DOMAIN_SSM_PARAM_NAME ?? `/SageMaker/DOMAINID`,
        efsIDSsmParameterName:
            process.env.EFS_SSM_PARAM_NAME ?? `/SageMaker/EFSID`,
        imageName: process.env.IMAGE_NAME ?? 'CodeImage',
    }
    let stack = new SageMakerAiMlflow(app, 'TestStack', stackProps)

    Aspects.of(app).add(new AwsSolutionsChecks({ verbose: true }))
    */

    test.todo(
        'Mock test during initial development, cdk-nag currently disabled.'
    )

    // test('No unsuppressed warnings', () => {
    //     const warnings = Annotations.fromStack(stack).findWarning(
    //         '*',
    //         Match.stringLikeRegexp('AwsSolutions-.*')
    //     )
    //     expect(warnings.length).toEqual(0)
    // })

    // test('No unsuppressed errors', () => {
    //     const errors = Annotations.fromStack(stack).findError(
    //         '*',
    //         Match.stringLikeRegexp('AwsSolutions-.*')
    //     )
    //     expect(errors.length).toEqual(0)
    // })
})
